Harry Potter II VR v1.0.2

DE: ZIP neben den vorhandenen System-Ordner entpacken, dann Start-HP2VR.cmd
starten und im Hauptmenü Flat oder VR wählen. Für VR SteamVR und Headset
vorher verbinden. Anleitung und Grenzen: HP2VR/README-DE.txt.

EN: Extract next to the existing System folder, run Start-HP2VR.cmd, then
choose Flat or VR in the main menu. Connect SteamVR/headset before VR.
Instructions and compatibility limits: HP2VR/README-EN.txt.

Eigene Originalinstallation erforderlich. Keine Spielstände im ZIP.
Requires your own original game. The ZIP contains no saved games.

Probleme? Diagnose-HP2VR.cmd erstellt eine ZIP zum Weitergeben an den Mod-Betreuer.
Problems? Diagnose-HP2VR.cmd creates a report ZIP to share with the mod maintainer.
Details: HP2VR/README-DIAGNOSE.txt. Kein automatischer Upload / No automatic upload.

Update von/from v1.0: Das separate Update-ZIP erhaelt Options.ini.
The separate update ZIP preserves Options.ini. Shared saves remain unchanged.
