HARRY POTTER II VR - v1.0.2

Installation
1. Installiere deine eigene PC-Version von Harry Potter und die Kammer des
   Schreckens. PrÃ¼fe zuerst, dass das normale Spiel auf deinem PC startet.
2. Entpacke dieses ZIP in den Spielordner. Start-HP2VR.cmd liegt danach NEBEN
   dem vorhandenen Ordner System. Es werden keine Originaldateien ersetzt.
3. Starte Start-HP2VR.cmd. Im ursprÃ¼nglichen HauptmenÃ¼ wÃ¤hlst du Flat oder VR.
   FÃ¼r VR zuerst SteamVR starten und das Headset verbinden.
   Eine vorhandene CD-/Desktop-VerknÃ¼pfung startet weiterhin das Originalspiel.
   Du kannst eine eigene VerknÃ¼pfung auf Start-HP2VR.cmd anlegen.

Flat startet die originale Game.exe ohne VR-Modifikation. VR verwendet die
Mod. Beide Modi benutzen dieselben sechs SpeicherplÃ¤tze des normalen Spiels.
Beim Wechsel wird das HauptmenÃ¼ neu geÃ¶ffnet. Beende das Startfenster erst,
nachdem das Spiel geschlossen wurde und die SpielstÃ¤nde abgeglichen sind.
Nach einem Absturz holt der nÃ¤chste Start fertig geschriebene VR-SpielstÃ¤nde
nach. UnvollstÃ¤ndige Save.tmp-Dateien werden niemals als Spielstand Ã¼bernommen.
Starte nicht gleichzeitig eine zweite Installation oder das Spiel direkt.

Voraussetzungen und Grenzen
- Windows 10/11 auf einem x64-PC, funktionierende Originalinstallation,
  SteamVR und ein darin eingerichtetes Headset mit zwei Controllern.
- Die Mod ist an die Engine-Version HPCos_021009_1205-1 gebunden. Vor VR-Start
  werden Game.exe, Engine-Komponenten und HGame.u geprÃ¼ft. Bei einer anderen
  Ausgabe/Patch-Version bleibt Flat verfÃ¼gbar; VR zeigt eine Fehlermeldung.
  Die Sprache allein sagt nichts Ã¼ber die unterstÃ¼tzte BinÃ¤rversion aus.
- Grafikausgabe Ã¼ber Direct3D 11 auf der von SteamVR gemeldeten Grafikkarte;
  kein fest eingebauter Hersteller oder GPU-Name. Andere PCs/Headsets wurden
  nicht physisch geprÃ¼ft. Kein Anspruch auf jede CD-Ausgabe oder jeden Treiber.
- Quest/Touch wurde praktisch getestet. Weitere Standardbelegungen und deren
  Grenzen stehen in CONTROLLERS.txt. SteamVR bietet eigene Controllerbelegung.
- Die komplette Handlung ist noch nicht lÃ¼ckenlos auf allen Systemen geprÃ¼ft.
  Drahtlose TonlÃ¼cken/Kompressionsartefakte kÃ¶nnen weiterhin auftreten.

Sprache und Leistung
Die zusÃ¤tzlichen Mod-MenÃ¼s erkennen Language aus Game.ini, ersatzweise aus
System/Default.ini. Deutsch wird deutsch angezeigt, Englisch englisch; andere
Sprachen verwenden fÃ¼r neue Mod-Texte Englisch. Texte, Stimmen und Ressourcen
des installierten Originalspiels bleiben in dessen Sprache.
In HP2VR/Options.ini kannst du Language=de/en/auto und Quality Ã¤ndern:
performance (1280), balanced (1536, Vorgabe), sharp (2048). Bei Ruckeln zuerst
performance probieren. Keine SteamVR-, WLAN- oder Audio-Systemeinstellungen
werden automatisch geÃ¤ndert. Die Mod lÃ¤dt beim Start nichts aus dem Internet.
ZusÃ¤tzlich begrenzt AutoQuality die AuflÃ¶sung anhand des lokalen Grafikspeicherbudgets:
unter 2 GB oder bei unbekanntem Speicher auf 1280, unter 4 GB auf 1536.
AutoQuality=0 in der Benutzerdatei config/hp2vr.ini hebt diese Begrenzung auf.
Die SpeicherprÃ¼fung ersetzt keine Leistungsmessung und garantiert keine Bildrate.

Steuerung (Touch, rechte Hand)
Linker Stick: laufen/seitwÃ¤rts; rechter Stick: drehen; A: springen/Flugaktion;
rechter Trigger: zaubern/werfen/auswÃ¤hlen; B: MenÃ¼/zurÃ¼ck; X: bestÃ¤tigen;
Y: Trank; linker Trigger: Karte; linker Griff halten: Handanzeige;
rechter Griff: gehen/Besen-Boost; linker Stickklick: Blick zentrieren;
rechter Stickklick: zusÃ¤tzlich speichern. SpeicherbÃ¼cher bleiben aktiv.
Im SpielmenÃ¼ unter Controllerbelegung lassen sich Aktionen neu belegen.
Filmsequenzen lassen sich dort zwischen Leinwand und 3D/360 Grad umschalten.

Fehler melden
Diagnose-HP2VR.cmd neben dem Starter erstellt eine ZIP mit Start- und
Laufzeitprotokollen, Windows-Version, Grafikadaptern und Dateiprüfungen.
Der Berichtsordner öffnet sich anschließend. Sende die ZIP mit einer kurzen
Fehlerbeschreibung und deinem Headset-Modell an den Mod-Betreuer.
Persönliche Pfade sowie Benutzer-/PC-Namen werden aus dem Bericht entfernt.
Spielstände und persönliche Einstellungen werden nicht eingepackt oder
verändert. Es gibt keinen automatischen Upload. Ein erneuter Absturz ist
nicht nötig. Details und eigene Datenpfade: README-DIAGNOSE.txt.
Fehlermeldungen verweisen auf das Werkzeug; Startfehler werden protokolliert.
v1.0.2 ergänzt einen Ausweichweg für abgelehnte Menü-/HUD-Grafikflächen.
Der gemeldete Speicherfehler wurde in Tests nachgestellt; die Bestätigung auf
dem betroffenen Test-PC steht noch aus.

Update von v1.0 oder v1.0.1
Das separate HP2VR-1.0.2-Update.zip in denselben Spielordner entpacken und die
enthaltenen Mod-Dateien ersetzen. Options.ini, Benutzerdaten und gemeinsame
Spielstände bleiben erhalten. Das vollständige ZIP ist für Neuinstallationen.

Daten, Sicherungen und Deinstallation
Benutzereinstellungen, private Laufzeitkopie, Protokolle und Sicherungen liegen
unter %LOCALAPPDATA%/HP2VR/<Installationskennung>. Der Starter schreibt keine
Mod-Dateien in System und benÃ¶tigt normalerweise keine Administratorrechte.
Ein schreibgeschÃ¼tzter Spielordner ist mÃ¶glich. Der normale Spielstand liegt
weiterhin im Windows-Dokumente-Ordner unter Harry Potter II/Save.
Bei unterschiedlichen Laufwerken liegen zusÃ¤tzliche Austausch-Sicherungen in
Save/.hp2vr-transactions. Alte SpielstÃ¤nde werden nicht stillschweigend gelÃ¶scht.
Diese Sicherungen enthalten persÃ¶nliche Spieldaten: zum Teilen NUR das
unverÃ¤nderte VerÃ¶ffentlichungs-ZIP verwenden, keine Laufzeit-/Save-Ordner.

Zum Entfernen: Spiel beenden, HP2VR-Ordner, Start-HP2VR.cmd, Diagnose-HP2VR.cmd
und README-HP2VR.txt aus dem
Spielverzeichnis entfernen. Deine Originaldateien und gemeinsamen SpielstÃ¤nde
bleiben erhalten. Benutzerdaten/Sicherungen erst entfernen, wenn du sie nicht
mehr brauchst. --check prÃ¼ft das Paket ohne Spielstart; --data-root PFAD erlaubt
einen kÃ¼rzeren, selbst gewÃ¤hlten Datenordner fÃ¼r sehr lange Windows-Benutzerpfade.

Inhalt
Dieses Paket enthÃ¤lt nur die Mod, kleine Laufzeitkomponenten und deren Lizenzen.
Keine Original-EXE, Spielgrafiken, Musik, SpielstÃ¤nde oder persÃ¶nlichen Profile.
Eine eigene Originalinstallation ist erforderlich. Inoffizielle Fan-Mod;
keine Verbindung zu den Rechteinhabern des Spiels oder SteamVR.
